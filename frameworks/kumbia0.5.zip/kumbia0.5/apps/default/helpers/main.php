<?php
/**
 * Todo helper que se coloque aqui estara disponible en toda la aplicacion
 **/
?>