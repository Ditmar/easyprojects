<h2>KumbiaError: No tiene Mod-ReWrite de Apache instalado</h2>
Debe habilitar/instalar mod_rewrite en su servidor Apache.

Consulte para m&aacute;s informaci&oacute;n:
<ul>
<li><a href='http://httpd.apache.org/docs/2.0/misc/rewriteguide.html'>http://httpd.apache.org/docs/2.0/misc/rewriteguide.html</a>
<li><a href='http://www.assembla.com/wiki/show/kumbia/Parte1-Capitulo3'>Wiki Kumbia</a>
</ul>



